export class Pago {}
