export class CreatePagoDto {}
